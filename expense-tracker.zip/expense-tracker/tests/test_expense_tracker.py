import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import expense_tracker as et


class TestExpenseTracker(unittest.TestCase):
    def setUp(self):
        self.data = []
        et.add_expense(self.data, 100, "Food", "lunch", "2026-10-01")
        et.add_expense(self.data, 50, "Transport", "bus", "2026-10-02")
        et.add_expense(self.data, 200, "Food", "dinner", "2026-09-30")

    def test_add_assigns_ids(self):
        self.assertEqual([e["id"] for e in self.data], [1, 2, 3])

    def test_invalid_amount(self):
        with self.assertRaises(ValueError):
            et.add_expense(self.data, -5, "Food")

    def test_invalid_date(self):
        with self.assertRaises(ValueError):
            et.add_expense(self.data, 5, "Food", "x", "01-10-2026")

    def test_total_by_category(self):
        self.assertEqual(et.total_by_category(self.data), {"Food": 300, "Transport": 50})

    def test_monthly_total(self):
        self.assertEqual(et.monthly_total(self.data, 2026, 10), 150)

    def test_delete(self):
        self.assertTrue(et.delete_expense(self.data, 2))
        self.assertFalse(et.delete_expense(self.data, 99))
        self.assertEqual(len(self.data), 2)

    def test_search(self):
        self.assertEqual(len(et.search(self.data, "BUS")), 1)

    def test_save_and_load(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.json")
            et.save_expenses(self.data, p)
            self.assertEqual(et.load_expenses(p), self.data)


if __name__ == "__main__":
    unittest.main()
